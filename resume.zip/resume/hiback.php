<!DOCTYPE html>
<html>
<head>
<title>David F. Bachor  -  Resume</title>

<meta name="viewport" content="width=device-width"/>
<meta name="description" content="The Curriculum Vitae of Joe Bloggs."/>
<meta charset="UTF-8"> 
</head>
<body>
	<p> Hiback this is the response</p>
</body>
</html>

